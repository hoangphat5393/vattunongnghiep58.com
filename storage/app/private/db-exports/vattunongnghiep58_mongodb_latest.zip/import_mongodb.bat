@echo off
chcp 65001 > nul
echo Importing JSON collections into MongoDB database: vattunongnghiep58
mongoimport --db vattunongnghiep58 --collection admin_menus --file collections\admin_menus.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection agent_conversation_messages --file collections\agent_conversation_messages.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection agent_conversations --file collections\agent_conversations.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection album_items --file collections\album_items.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection albums --file collections\albums.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection cache --file collections\cache.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection cache_locks --file collections\cache_locks.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection categories --file collections\categories.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection contacts --file collections\contacts.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection countries --file collections\countries.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection currencies --file collections\currencies.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection customer_forget_pass_otp --file collections\customer_forget_pass_otp.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection email_templates --file collections\email_templates.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection failed_jobs --file collections\failed_jobs.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection import_log --file collections\import_log.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection jobs --file collections\jobs.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection media_files --file collections\media_files.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection menu_items --file collections\menu_items.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection menus --file collections\menus.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection order_items --file collections\order_items.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection order_payments --file collections\order_payments.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection orders --file collections\orders.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection pages --file collections\pages.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection password_reset_tokens --file collections\password_reset_tokens.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection payment_methods --file collections\payment_methods.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection permission_role --file collections\permission_role.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection permissions --file collections\permissions.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection product_categories --file collections\product_categories.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection product_prices --file collections\product_prices.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection products --file collections\products.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection role_user --file collections\role_user.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection roles --file collections\roles.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection sessions --file collections\sessions.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection settings --file collections\settings.json --jsonArray --drop
mongoimport --db vattunongnghiep58 --collection users --file collections\users.json --jsonArray --drop
echo Done!
pause
