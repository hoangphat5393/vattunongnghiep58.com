#!/usr/bin/env bash
set -e
DB_NAME="${1:-vattunongnghiep58}"
echo "Importing JSON collections into MongoDB database: $DB_NAME"
mongoimport --db "$DB_NAME" --collection admin_menus --file collections/admin_menus.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection agent_conversation_messages --file collections/agent_conversation_messages.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection agent_conversations --file collections/agent_conversations.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection album_items --file collections/album_items.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection albums --file collections/albums.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection cache --file collections/cache.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection cache_locks --file collections/cache_locks.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection categories --file collections/categories.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection contacts --file collections/contacts.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection countries --file collections/countries.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection currencies --file collections/currencies.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection customer_forget_pass_otp --file collections/customer_forget_pass_otp.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection email_templates --file collections/email_templates.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection failed_jobs --file collections/failed_jobs.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection import_log --file collections/import_log.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection jobs --file collections/jobs.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection media_files --file collections/media_files.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection menu_items --file collections/menu_items.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection menus --file collections/menus.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection order_items --file collections/order_items.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection order_payments --file collections/order_payments.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection orders --file collections/orders.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection pages --file collections/pages.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection password_reset_tokens --file collections/password_reset_tokens.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection payment_methods --file collections/payment_methods.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection permission_role --file collections/permission_role.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection permissions --file collections/permissions.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection product_categories --file collections/product_categories.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection product_prices --file collections/product_prices.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection products --file collections/products.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection role_user --file collections/role_user.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection roles --file collections/roles.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection sessions --file collections/sessions.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection settings --file collections/settings.json --jsonArray --drop
mongoimport --db "$DB_NAME" --collection users --file collections/users.json --jsonArray --drop
echo "Done!"
